package com.pokemmo.bot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class GoldFarmActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("gold_farm", MODE_PRIVATE) }
    private lateinit var targetInput: EditText
    private lateinit var earnedInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "GOLD FARM"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "Bảng điều khiển theo dõi mục tiêu vàng"
            textSize = 14f
        })

        targetInput = EditText(this).apply {
            hint = "Mục tiêu vàng (ví dụ: 100000)"
            inputType = 2
            setText(prefs.getString("target", "100000"))
        }
        earnedInput = EditText(this).apply {
            hint = "Vàng đã kiếm được"
            inputType = 2
            setText(prefs.getString("earned", "0"))
        }
        statusText = TextView(this).apply {
            textSize = 16f
            text = "Trạng thái: Sẵn sàng"
        }

        root.addView(targetInput)
        root.addView(earnedInput)
        root.addView(statusText)
        root.addView(Button(this).apply {
            text = "Lưu cấu hình"
            setOnClickListener {
                prefs.edit()
                    .putString("target", targetInput.text.toString())
                    .putString("earned", earnedInput.text.toString())
                    .apply()
                Toast.makeText(this@GoldFarmActivity, "Đã lưu cấu hình", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Start"
            setOnClickListener {
                statusText.text = "Trạng thái: Đang theo dõi phiên cày vàng"
            }
        })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener {
                statusText.text = "Trạng thái: Đã dừng"
            }
        })
        root.addView(Button(this).apply {
            text = "Đóng"
            setOnClickListener { finish() }
        })
        setContentView(root)
    }
}
