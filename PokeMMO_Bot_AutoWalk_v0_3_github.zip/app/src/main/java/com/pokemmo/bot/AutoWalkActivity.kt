package com.pokemmo.bot

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

class AutoWalkActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("autowalk_destinations", MODE_PRIVATE) }
    private val regions = listOf("Kanto", "Hoenn", "Sinnoh", "Unova", "Johto")
    private var region = "Unova"
    private var mapUri: Uri? = null
    private var destinationX = -1f
    private var destinationY = -1f
    private lateinit var mapView: DestinationMapView
    private lateinit var mapStatus: TextView
    private lateinit var destinationStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        region = prefs.getString("active_region", "Unova") ?: "Unova"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 22)
        }
        root.addView(TextView(this).apply {
            text = "AUTO WALK • MAP PICKER"
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "Chọn region riêng, tải bản đồ và chạm để đặt điểm đến."
            textSize = 14f
        })

        val regionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        regions.forEach { r ->
            regionRow.addView(Button(this).apply {
                text = r
                textSize = 10f
                setOnClickListener { selectRegion(r) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(regionRow)

        mapStatus = TextView(this).apply { textSize = 13f; setPadding(0, 8, 0, 8) }
        root.addView(mapStatus)
        root.addView(Button(this).apply {
            text = "Load map image"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(intent, REQUEST_MAP)
            }
        })

        mapView = DestinationMapView()
        root.addView(mapView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = 8; bottomMargin = 8 })

        destinationStatus = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 8) }
        root.addView(destinationStatus)
        root.addView(Button(this).apply {
            text = "Save destination"
            setOnClickListener {
                if (destinationX < 0f || mapUri == null) {
                    Toast.makeText(this@AutoWalkActivity, "Load map and tap destination first", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit()
                        .putString("${region}_map_uri", mapUri.toString())
                        .putFloat("${region}_dest_x", destinationX)
                        .putFloat("${region}_dest_y", destinationY)
                        .apply()
                    Toast.makeText(this@AutoWalkActivity, "$region destination saved", Toast.LENGTH_SHORT).show()
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Clear destination"
            setOnClickListener {
                destinationX = -1f; destinationY = -1f
                prefs.edit().remove("${region}_dest_x").remove("${region}_dest_y").apply()
                mapView.invalidate()
                updateDestinationText()
            }
        })
        root.addView(TextView(this).apply {
            text = "Prototype: điểm được lưu theo region. Chưa tự tìm đường hoặc điều khiển nhân vật."
            textSize = 12f
        })
        root.addView(Button(this).apply { text = "Close"; setOnClickListener { finish() } })
        setContentView(root)
        loadRegionData()
    }

    private fun selectRegion(value: String) {
        region = value
        prefs.edit().putString("active_region", region).apply()
        loadRegionData()
    }

    private fun loadRegionData() {
        mapUri = prefs.getString("${region}_map_uri", null)?.let { Uri.parse(it) }
        destinationX = prefs.getFloat("${region}_dest_x", -1f)
        destinationY = prefs.getFloat("${region}_dest_y", -1f)
        mapStatus.text = "Region: $region • " + if (mapUri == null) "No map loaded" else "Map loaded"
        mapView.loadMap(mapUri)
        mapView.invalidate()
        updateDestinationText()
    }

    private fun updateDestinationText() {
        destinationStatus.text = if (destinationX >= 0f)
            "Destination: ${(destinationX * 100).toInt()}%, ${(destinationY * 100).toInt()}% (map-relative)"
        else "Destination: not selected"
    }

    @Deprecated("Deprecated in Android API; retained for minSdk 23 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MAP && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                mapUri = uri
                prefs.edit().putString("${region}_map_uri", uri.toString()).apply()
                mapView.loadMap(uri)
                mapStatus.text = "Region: $region • Map loaded"
            }
        }
    }

    inner class DestinationMapView : View(this@AutoWalkActivity) {
        private var bitmap: android.graphics.Bitmap? = null
        private val mapPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.RED; style = Paint.Style.FILL
        }
        private val markerOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
        }
        fun loadMap(uri: Uri?) {
            bitmap = try { uri?.let { contentResolver.openInputStream(it)?.use { stream -> BitmapFactory.decodeStream(stream) } } }
            catch (_: Exception) { null }
            invalidate()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(0xFF252932.toInt())
            val b = bitmap
            if (b == null) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 38f; textAlign = Paint.Align.CENTER }
                canvas.drawText("Load a map image", width / 2f, height / 2f, p)
                return
            }
            val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
            val w = b.width * scale; val h = b.height * scale
            val left = (width - w) / 2f; val top = (height - h) / 2f
            canvas.drawBitmap(b, null, android.graphics.RectF(left, top, left + w, top + h), mapPaint)
            if (destinationX >= 0f) {
                val x = left + destinationX * w
                val y = top + destinationY * h
                canvas.drawCircle(x, y, 18f, markerOutline)
                canvas.drawCircle(x, y, 14f, markerPaint)
            }
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                val b = bitmap ?: return false
                val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
                val w = b.width * scale; val h = b.height * scale
                val left = (width - w) / 2f; val top = (height - h) / 2f
                if (event.x in left..(left + w) && event.y in top..(top + h)) {
                    destinationX = (event.x - left) / w
                    destinationY = (event.y - top) / h
                    invalidate()
                    updateDestinationText()
                    return true
                }
            }
            return true
        }
    }

    companion object { private const val REQUEST_MAP = 7001 }
}
