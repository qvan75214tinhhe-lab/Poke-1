package com.pokemmo.bot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class GymRematchActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("gym_rematch", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var winsInput: EditText
    private lateinit var rewardInput: EditText
    private lateinit var gymChecks: List<CheckBox>

    private val gymNames = listOf(
        "Gym 1", "Gym 2", "Gym 3", "Gym 4",
        "Gym 5", "Gym 6", "Gym 7", "Gym 8"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 32, 26, 26)
        }
        root.addView(TextView(this).apply {
            text = "GYM REMATCH"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "Chọn các Gym muốn đưa vào danh sách đánh lại"
            textSize = 14f
        })

        gymChecks = gymNames.mapIndexed { index, name ->
            CheckBox(this).apply {
                text = name
                isChecked = prefs.getBoolean("gym_$index", false)
                root.addView(this)
            }
        }

        winsInput = EditText(this).apply {
            hint = "Số trận thắng (nhập thủ công)"
            inputType = 2
            setText(prefs.getString("wins", "0"))
        }
        rewardInput = EditText(this).apply {
            hint = "Tổng tiền thưởng (nhập thủ công)"
            inputType = 2
            setText(prefs.getString("reward", "0"))
        }
        root.addView(winsInput)
        root.addView(rewardInput)

        status = TextView(this).apply {
            textSize = 16f
            text = "Trạng thái: Sẵn sàng"
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Lưu danh sách Gym"
            setOnClickListener {
                val edit = prefs.edit()
                gymChecks.forEachIndexed { index, check ->
                    edit.putBoolean("gym_$index", check.isChecked)
                }
                edit.putString("wins", winsInput.text.toString())
                edit.putString("reward", rewardInput.text.toString())
                edit.apply()
                Toast.makeText(this@GymRematchActivity, "Đã lưu danh sách", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Start"
            setOnClickListener {
                val selected = gymChecks.count { it.isChecked }
                status.text = if (selected == 0) {
                    "Trạng thái: Chưa chọn Gym"
                } else {
                    "Trạng thái: Đang theo dõi danh sách $selected Gym"
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener { status.text = "Trạng thái: Đã dừng" }
        })
        root.addView(Button(this).apply {
            text = "Đóng"
            setOnClickListener { finish() }
        })
        setContentView(root)
    }
}
