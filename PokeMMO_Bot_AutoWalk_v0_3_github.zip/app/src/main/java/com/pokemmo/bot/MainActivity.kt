package com.pokemmo.bot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "PokeMMO Bot v0.2.2\nFloating control prototype"
            textSize = 22f
        })
        layout.addView(TextView(this).apply {
            text = "\nModules: Auto Walk, Route Manager, Hunt, Train, Gold Farm, Gym Rematch"
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Open Gym Rematch"
            setOnClickListener { startActivity(Intent(this@MainActivity, GymRematchActivity::class.java)) }
        })
        layout.addView(Button(this).apply {
            text = "Open Gold Farm"
            setOnClickListener { startActivity(Intent(this@MainActivity, GoldFarmActivity::class.java)) }
        })
        layout.addView(Button(this).apply {
            text = "Enable floating menu"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    ))
                } else {
                    startService(Intent(this@MainActivity, FloatingMenuService::class.java))
                    Toast.makeText(this@MainActivity, "Floating menu started", Toast.LENGTH_SHORT).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Stop floating menu"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingMenuService::class.java))
            }
        })
        setContentView(layout)
    }
}
