# PokeMMO Bot v0.2.2

## Included modules
- Floating menu with draggable header
- Auto Walk, Route Manager, Hunt, Train placeholders
- Gold Farm tracking screen (manual gold entry, saved settings)
- Gym Rematch screen:
  - Select from eight editable placeholder gym slots (Gym 1–8)
  - Save selected gym slots
  - Start/Stop display state
  - Manual win and reward counters

## Current limitations
Gym Rematch is currently a UI/configuration and manual tracking scaffold.
It does not identify gyms in-game, start battles, select teams/moves, or repeat battles.
Gym names are generic placeholders and should be replaced with the user's actual route/region list.
Gold Farm is also a manual tracker, not an in-game automation module.

## Build
Open in Android Studio with JDK 17, sync Gradle, then Build > Build APK(s).


## Auto Walk Map Picker prototype (v0.3)
- Added Auto Walk activity launched from main screen and floating menu.
- Select one of five regions: Kanto, Hoenn, Sinnoh, Unova, Johto.
- Load a map image from device storage per region.
- Tap the image to set a destination marker.
- Save/clear destination independently for each region.

Limitations: this is a destination-selection prototype. It does not perform pathfinding,
recognize in-game position, avoid obstacles, or control PokeMMO movement yet. The selected
point is stored as normalized image coordinates (0–100%), not game tile coordinates.
